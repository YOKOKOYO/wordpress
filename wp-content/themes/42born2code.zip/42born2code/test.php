<?php mail('hmoutaou@student.42.fr', 'ads', 'asdd'); ?>
